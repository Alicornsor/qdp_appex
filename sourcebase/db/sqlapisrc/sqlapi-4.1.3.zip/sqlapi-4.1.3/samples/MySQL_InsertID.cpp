#include <myAPI.h>

void MySQL_InsertID()
{
	SAConnection con; // connection object
    SACommand cmd(&con, "insert into t2(f2) values('new line')");
	
	try
	{
		con.Connect("test", "ODBC", "", SA_MySQL_Client);
		cout << (const char*)con.ServerVersionString() << endl;
		cout << (con.ClientVersion() >> 16) << "."
			<< (con.ClientVersion() &0x0000FFFF) << endl;

		cmd.Execute();
		
		myAPI* p_myAPI = (myAPI*)con.NativeAPI();
		myConnectionHandles* p_myConnHandles =
			(myConnectionHandles*)con.NativeHandles();


		cout << "new value of the auto increment field: " <<
			(long)p_myAPI->mysql_insert_id(p_myConnHandles->mysql) << endl;
	}
    catch(SAException &x)
    {
        // print error message
        printf("%s\n", (const char*)x.ErrText());
    }
}
