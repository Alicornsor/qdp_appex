#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <ctype.h>

#include <string>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <iostream>
#include <time.h>

#include <SQLAPI.h>
#include <samisc.h>

/*
create table TEST(C_LONG LONG);
*/
int main(int argc, char* argv[])
{
	SAConnection con; // create connection object

	try
	{
		con.Connect(
			"ora111",  // database name
			"yas",				// user name
			"java",			// password
			SA_Oracle_Client);

		{
	        	SACommand startCmd(&con, "SET TRANSACTION READ WRITE");
	        	startCmd.Execute();
		}
			
		{
			// Clear database
			SACommand cmd(&con, _TSA("delete from TEST"));
			cmd.Execute();
		}
			
		{	
			SACommand cmd1(&con, _TSA("insert into TEST (C_LONG) values (:1)"));
			cmd1.Param(1).setAsLongChar() = _TSA("hello helllo hellllo");
			cmd1.Execute();
		}
		
		{
			// Commit transaction
		        con.Commit();
		}

		SACommand cmd(&con);
		cmd.setCommandText(_TSA("select f2 from t1 where f1=1"));
		cmd.Execute();


		while( cmd.isResultSet() )
		{
			while( cmd.FetchNext() )
			{
				sa_printf((const SAChar*)cmd[1].asLongChar());
				sa_printf(_TSA("\n"));
			}
		}
	}
	catch(SAException &x)
	{
		sa_printf(_TSA("ERR: "));
		sa_printf((const SAChar*)x.ErrText());
		sa_printf(_TSA("\n"));
	}
	return 0;
}
