﻿#define _CRT_SECURE_NO_DEPRECATE	1

#define _CRT_SECURE_NO_WARNINGS		1



#include <stdio.h>

#include <stdlib.h>

#include <conio.h>

#include <ctype.h>

#include <iostream>



#ifdef WIN32

#include <windows.h>

#include <tchar.h>

#endif



#include <SQLAPI.h>

#include <samisc.h>



#include <cstdlib>

#include <iostream>

#include <time.h>

#include <assert.h>

#include <chrono>

#include <vector>



using namespace std;



static FILE *pFile = NULL;

size_t nTotalBound;



size_t FromFileWriter( SAPieceType_t &ePieceType,

					  void *pBuf, size_t nLen, void *pAddlData)

{

	if(ePieceType == SA_FirstPiece)

	{

		const char *sFilename = (const char *)pAddlData;

		pFile = fopen(sFilename, "rb");

		if(!pFile)

			SAException::throwUserException(-1,

			_TSA("Can not open file '%s'"),

			(const SAChar*)SAString(sFilename));



		nTotalBound = 0;

	}



	size_t nRead = fread(pBuf, 1, nLen, pFile);

	nTotalBound += nRead;

	// show progress

	printf("%d bytes of file bound\n", nTotalBound);



	if(feof(pFile))

	{

		if( ePieceType == SA_FirstPiece )

			ePieceType = SA_OnePiece;

		else

			ePieceType = SA_LastPiece;

		fclose(pFile);

		pFile = NULL;

	}



	return nRead;

}



SAString ReadWholeFile(const char *sFilename)

{

	SAString s;

	char sBuf[1024];

	FILE *pFile = fopen(sFilename, "rb");



	if(!pFile)

		SAException::throwUserException(-1, 

		_TSA("Error opening file '%s'\n"),

		(const SAChar*)SAString(sFilename));

	do

	{

		size_t nRead = fread(sBuf, 1, sizeof(sBuf), pFile);

		s += SAString((const void*)sBuf, nRead);

	}

	while(!feof(pFile));



	fclose(pFile);



	return s;

}



SAString ReadWholeTextFile(const SAChar *szFilename)

{

	SAString s;

	char szBuf[32*1024];

	FILE *pFile = _tfopen(szFilename, _TSA("rb"));



	if( ! pFile )

		SAException::throwUserException(-1, 

		_TSA("Error opening file '%s'\n"),

		(const SAChar*)SAString(szFilename));

	do

	{

		size_t nRead = fread(szBuf, 1, sizeof(szBuf), pFile);

		s += SAString(szBuf, nRead);

	}

	while(!feof(pFile));



	fclose(pFile);



	return s;

}



void WriteWholeFile(const char *sFilename, const SAString& data)

{

	FILE *pFile = fopen(sFilename, "wb");



	size_t n, written = 0, len = data.GetBinaryLength();

	const void* pData = (const void*)data;



	sa_printf(_TSA("PRGLEN: %d\n"), len);



	if(!pFile)

		SAException::throwUserException(-1,

		_TSA("Error opening file '%s'\n"),

		(const SAChar*)SAString(sFilename));



	while( len > written ) {

		n = fwrite((const char*)pData+written, 1, sa_min(1024,len-written), pFile);

		if( n <= 0 )

			break;

		written += n;

	}



	fclose(pFile);

}



size_t nTotalRead;



void IntoFileReader(

	SAPieceType_t ePieceType,

	void *pBuf,

	size_t nLen,

	size_t nBlobSize,

	void *pAddlData)

{

	const char *sFilename = (const char *)pAddlData;



	if(ePieceType == SA_FirstPiece || ePieceType == SA_OnePiece)

	{

		nTotalRead = 0;

		pFile = fopen(sFilename, "wb");

		if(!pFile)

			SAException::throwUserException(-1,

			_TSA("Can not open file '%s' for writing"),

			(const SAChar*)SAString(sFilename));

	}



	fwrite(pBuf, 1, nLen, pFile);

	nTotalRead += nLen;



	if(ePieceType == SA_LastPiece || ePieceType == SA_OnePiece)

	{

		fclose(pFile);

		pFile = NULL;

		printf("%s : %d bytes of %d read\n",

			sFilename, nTotalRead, nBlobSize);

	}

}



void Ora_Fetch_Cursor(SACommand& cmd, int stage)

{

	for(int s = 1; s < stage; ++s) printf(" ");

	printf("START CURSOR #%d\n", stage);



	try

	{

		if( cmd.isResultSet() )

		{

			//cmd.setOption(SACMD_PREFETCH_ROWS) = _TSA("5");

			while( cmd.FetchNext() )

			{

				for( int i = 1; i <= cmd.FieldCount(); ++i )

				{

					SAField& f = cmd.Field(i);

					if( SA_dtCursor == f.FieldType() )

					{

						SACommand* cur = f.asCursor();

						if( NULL == cur)

						{

							for(int s = 1; s < stage; ++s) printf(" ");

							printf("NULL result set\n");

						}

						else

							Ora_Fetch_Cursor(*cur, stage + 1);

					}

					else

					{

						for(int s = 1; s < stage; ++s) printf(" ");

						printf("VAL #%d: %s\n",

							i, f.asString().GetMultiByteChars());

					}

				}

			}

		}

		else

		{

			for(int s = 1; s < stage; ++s) printf(" ");

			printf("Empty result set\n");

		}

	}

	catch(SAException &x)

	{	

		for(int s = 1; s < stage; ++s) printf(" ");

		printf("ERROR: %s\n", x.ErrText().GetMultiByteChars());

	}



	for(int s = 1; s < stage; ++s) printf(" ");

	printf("END CURSOR #%d\n", stage);

}



/*

create function func1

return sys_refcursor

is

v_cur			sys_refcursor;

begin

open v_cur for

select

1 a

, cursor(select level l from dual connect by level < 5) c

from dual

connect by level < 5;

return v_cur;

end;



create procedure proc1 (p_cur out sys_refcursor)

is

begin

open p_cur for

select level l from dual connect by level < 50;

end;

/

*/

int Oracle_RefCur()

{

	SAConnection con;

	//con.setOption(_TSA("UseAPI")) = _TSA("OCI7");



	try {

		con.Connect(_TSA("ora102"),

			_TSA("scott"), _TSA("tiger"), SA_Oracle_Client);



		SACommand cmd(&con, _TSA("select func1() from t1"));

		//SACommand cmd(&con, _TSA("proc1"));

		while( true )

		{

			//cmd.setOption(SACMD_PREFETCH_ROWS) = _TSA("5");



			cmd.Execute();

			Ora_Fetch_Cursor(cmd, 1);



			/*

			SACommand* pCur = cmd.Param(_TSA("p_routes")).asCursor();

			if( NULL != pCur )

			Ora_Fetch_Cursor(*pCur, 1);

			*/

		}

	}

	catch(SAException &x)

	{	

		printf("ERROR: %s\n", x.ErrText().GetMultiByteChars());

	}



	return 0;

}



/*

create table t1(f1 integer not null, f2 clob);

insert into t1(f1,f2) values(1,NULL);



create or replace procedure test_sp(po_file OUT CLOB) IS

BEGIN

select f2 into po_file from t1 where f1=1;

END;

*/



int FB2_LastInsert()

{

	/*

	CREATE TABLE T1

	(

	F1 INTEGER NOT NULL,

	F2 VARCHAR(20) NOT NULL

	);



	CREATE GENERATOR GEN_T1_F1;

	SET GENERATOR GEN_T1_F1 TO 0;



	SET TERM !! ;

	CREATE TRIGGER T1_BI FOR T1

	ACTIVE BEFORE INSERT POSITION 0

	AS

	BEGIN

	IF (NEW.F1 IS NULL) THEN

	NEW.F1 = GEN_ID(GEN_T1_F1, 1);

	END!!

	SET TERM ; !!

	*/



	SAConnection con;

	SACommand cmd(&con,

		_TSA("INSERT INTO t1 (f2) values ('val x') returning f1")); 



	try

	{

		con.Connect(_TSA("test"), _TSA("sysdba"), _TSA("masterkey"),

			SA_InterBase_Client);

		cmd.Execute();

		if( cmd.FetchNext() )

			printf("F1 value: %d\n", cmd.Field(1).asLong());



	}

	catch(SAException &x)

	{

		// SAConnection::Rollback()

		// can also throw an exception

		// (if a network error for example),

		// we will be ready

		try

		{

			// on error rollback changes

			con.Rollback();

		}

		catch(SAException &)

		{

		}

		// print error message

		printf("%s\n", x.ErrText().GetMultiByteChars());

	}



	return 0;

}



void test_scroll(SAConnection &con)

{

	SACommand cmd(&con);

	//cmd.setOption(SACMD_PREFETCH_ROWS) = _TSA("5"); // wronf value!!!???

	cmd.setOption(SACMD_PREFETCH_ROWS) = _TSA("3");

	cmd.setOption(SACMD_SCROLLABLE) = _TSA("1");



	cmd.setCommandText(_TSA("select f1 from t1"));

	cmd.Execute();



	int ch;

	printf("ENTER n,p,f,l or q to quit.\n");



	do {

		ch = _getch();

		bool bResult = false;



		try

		{

			switch(ch)

			{

			case 'n':

				bResult = cmd.FetchNext();

				break;

			case 'p':

				bResult = cmd.FetchPrior();

				break;

			case 'f':

				bResult = cmd.FetchFirst();

				break;

			case 'l':

				bResult = cmd.FetchLast();

				break;

			}

		}

		catch(SAException &x)

		{

			printf("ERROR: %s\n", x.ErrText().GetMultiByteChars());

		}



		if( bResult )

			printf("RESULT: %s.\n", cmd[1].asString().GetMultiByteChars());

		else if( ch != 'q' )

			printf("NO DATA.\n");



	} while ( ch != 'q' );

}



#ifdef WIN32

typedef struct _saCmdExec {

	SACommand* c;

	SAString s;

} saCmdExec_t;



static DWORD WINAPI SACommandExecuteThread(void *lpParam)

{

	saCmdExec_t* saCmdExec = static_cast<saCmdExec_t*>(lpParam);

	try

	{

		saCmdExec->c->Execute();

	}

	catch(SAException& x)

	{

		saCmdExec->s = x.ErrText();

		return DWORD(1);

	}

	return DWORD(0);

}



void SACommandExecute(SACommand* cmd, DWORD dwMilliseconds)

{

	DWORD dwThreadId;

	saCmdExec_t saCmdExec = {NULL, _TSA("")};

	HANDLE hThread = ::CreateThread(NULL, 0,

		SACommandExecuteThread, &saCmdExec, 0, &dwThreadId);

	if( WAIT_TIMEOUT == ::WaitForSingleObject(hThread, dwMilliseconds) )

	{

		cmd->Cancel();

		SAException::throwUserException(-1, _TSA("Command timeout!"));

	}

	else if( ! saCmdExec.s.IsEmpty() )

		SAException::throwUserException(-1, _T("%s"), (const SAChar*)saCmdExec.s);

}

#endif



/*

int main(int argc, char** argv)

{

char s[512];

double x1 = 12.34;

double x2 = x1 * 100;

double x3 = x2 / 100;

sprintf(s, "%f", x3 * 100.0);

double x4 = atof(s);



double dVal = 12345.67890;

printf("%.15f\n", dVal);



char* x = setlocale(LC_ALL, "Russian");



double d0 = 12.3456;

SANumeric SANum;

SANum = SANumeric(d0);

printf("NUM(%d,%d)=%s, D=%f\n", SANum.precision, SANum.scale, ((SAString)SANum).GetMultiByteChars(), (double)SANum);

SANum.precision = 10;

SANum.scale = 6;

printf("NUM(%d,%d)=%s, D=%f\n", SANum.precision, SANum.scale, ((SAString)SANum).GetMultiByteChars(), (double)SANum);

SANum.precision = 10;

SANum.scale = 2;

printf("NUM(%d,%d)=%s, D=%f\n", SANum.precision, SANum.scale, ((SAString)SANum).GetMultiByteChars(), (double)SANum);



SAConnection con;

try

{

//con.Connect(_TSA("bedlamm@sample", "sa", "root", SA_Sybase_Client);

//con.setOption(_TSA("ClientEncoding")) = _TSA("latin1");

//con.Connect(_TSA("DSN=ol_informix1170;CLIENT_LOCALE=ru_RU.1251"),

//con.Connect(_TSA("PRO=olsoctcp;SERV=turbo;SRVR=ol_inf;HOST=localhost;DATABASE=sysuser"),

//con.Connect(_TSA("ol_inf"),

//	_TSA("informix"), _TSA("java"), SA_Informix_Client);

//con.setOption(_TSA("SQLNCLI.LIBS")) = _TSA("sqlncli11.dll");

//con.Connect(_TSA("bedlam-m\\en2012@test"), _TSA(""), _TSA(""), SA_SQLServer_Client);

con.Connect(_TSA("bedlam-m\\en2008R2@test"), _TSA(""), _TSA(""), SA_SQLServer_Client);

//con.Connect(_TSA("test"), _TSA(""), _TSA(""), SA_DB2_Client);



//con.Connect(_TSA("test"), _TSA("postgres"), _TSA("java"), SA_PostgreSQL_Client);



SACommand cmd(&con);

cmd.setCommandText(_TSA("SELECT @@SPID AS 'ID', SYSTEM_USER AS 'Login Name', USER AS 'User Name'"));

//cmd.Param("in_we").setAsLong() = 5;

cmd.Execute(); 

while( cmd.FetchNext() )

{

for(int i=1; i <= cmd.FieldCount(); ++i)

{

SAField& p = cmd[i];

sa_printf((const SAChar*)p.Name());

sa_printf(_TSA(" = "));

sa_printf((const SAChar*)p.asString());

sa_printf(_TSA("\n"));

}

}



LPBYTE inData = (LPBYTE)malloc(1024);

memset(inData, 'x', 1024);



cmd.setCommandText(_TSA("update t1 set f2=:1 where f1=1"));

cmd.Param(1).setAsBytes() = SAString((const void*)inData, 1024);

cmd.Execute();



cmd.setCommandText(_TSA("select f2 from t1 where f1=1"));

cmd.Execute();

while(cmd.FetchNext())

{

SAString sData = cmd[1].asBytes();

// outData is accessible only until sData is not destroyed

LPCBYTE outData = (LPCBYTE)((const void*)sData);

size_t outDataLenght = sData.GetBinaryLength();

}





//cmd.setCommandText(_TSA("create table t1(f1 integer, f2 varchar(200))"));

//cmd.Execute();

//cmd.setCommandText(_TSA("update t1 set f2=:1 where f1=1"));

//cmd.Param(1).setAsString() = _TSA("!!!просто новая очень строка!!!");

//cmd.Execute();



//con.Commit();



//cmd.Param(1).setOption("") = "";



//cmd.setCommandText(_TSA("select * from TestDatabase"));

cmd.setCommandText(_TSA("select f2,f3 from t1"));

cmd.Execute();

while( cmd.FetchNext() ) {

SAString s1 = cmd[1].asString();

SAString s2 = cmd[2].asString();

sa_printf((const SAChar*)s1);

sa_printf(_TSA(", "));

sa_printf((const SAChar*)s2);

sa_printf(_TSA("\n"));

}

}

catch( SAException &x )

{

sa_printf(_TSA("ERR: "));

sa_printf((const SAChar*) x.ErrText());

sa_printf(_TSA("\n"));

}



return 0;

}

*/





/*

CREATE TABLE CSVTest

(ID INT,

FirstName VARCHAR(40),

LastName VARCHAR(40),

BirthDate SMALLDATETIME)

go



d:\csvtest.txt



1,James,Smith,19750101

2,Meggie,Smith,19790122

3,Robert,Smith,20071101

4,Alex,Smith,20040202

*/

int main1(int argc, char** argv)

{

	SAConnection con; // connection object

	SACommand cmd;    // create command object



	bool bUseAutoCommit = false;

	bool bUseBind = false;

	bool bUseResult = false;



	for( int i = 1; i < argc; ++i )

	{

		if (0 == _stricmp(argv[i], "bind"))

			bUseBind = true;

		else if (0 == _stricmp(argv[i], "commit"))

			bUseAutoCommit = true;

		else if (0 == _stricmp(argv[i], "true"))

			bUseResult = true;

	}



	try

	{

		con.setOption(_TSA("UseAPI")) = _TSA("OLEDB");

		con.setOption(_TSA("OLEDBProvider")) = _TSA("CompactEdition");

		//con.setOption(_TSA("CreateDatabase")) = _TSA("VARIANT_TRUE");

		con.Connect(_TSA("D:\\test.sdf"), _TSA(""), _TSA(""), SA_SQLServer_Client);

		con.setAutoCommit(bUseAutoCommit ? SA_AutoCommitOn:SA_AutoCommitOff);



		cmd.setConnection(&con);



		//cmd.setCommandText(L"create table tblTestData(strText nvarchar(100))");

		//cmd.Execute();



		if( ! bUseResult )

			cmd.setOption(_TSA("Execute_riid")) = _TSA("IID_NULL");



		//do the insert

		if( bUseBind )

		{

			cmd.setCommandText(L"INSERT tblTestData (strText) VALUES (:1)");

			cmd.Param(1).setAsString() = "Hello World";

		}

		else

			cmd.setCommandText(L"INSERT tblTestData (strText) VALUES ('Hello World')");



		cmd.setOption(_TSA("ICommandPrepare")) = _TSA("required");



		std::chrono::time_point<std::chrono::system_clock> start, end;

		start = std::chrono::system_clock::now();

		for (int ii = 0; ii < 123456; ++ii)

		{

			cmd.Execute();

		}

		end = std::chrono::system_clock::now();



		std::chrono::duration<double> duration = end - start;

		std::cout << duration.count() << std::endl;



		start = std::chrono::system_clock::now();

		for (int ii = 0; ii < 123456; ++ii)

		{

			cmd.Execute();

		}



		end = std::chrono::system_clock::now();

		duration = end - start;

		std::cout << duration.count() << std::endl;



		cmd.setCommandText("DELETE from tblTestData");

		cmd.Execute();

		con.Commit();

	}

	catch (SAException & e)

	{

		//char tChar[255];

		//sprintf(tChar, "%s\n", (const char*) e.ErrText());

		//std::string strText(e.ErrText().GetWideChars());

		//std::cout << e.ErrText() << std::endl;

		for (int ii = 0; ii < e.ErrText().GetWideCharsLength(); ii++)

		{

			std::cout << (char) e.ErrText().GetWideChars()[ii];

		}

		std::cout << std::endl;

	}



	std::cout << "Hit any key to continue...";

	_getch();



	return 0;

}



using std::cout;

using std::cin;



int mainxxx(int argc, char* argv[])

{

	//setlocale(LC_ALL, "Russian");



	SAConnection con; // create connection object







	try

	{

		//con.setOption(_TSA("UseAPI")) = _TSA("OLEDB");

		//con.setOption(_TSA("OLEDBProvider")) = _TSA("SQLOLEDB");



		con.Connect(

			"test",  // database name

			"root",				// user name

			"",			// password

			SA_MySQL_Client);



		SACommand cmd(&con, _TSA("insert into t2(f2) values('xx')"));

		cmd.Execute();



		cmd.setCommandText(_TSA("select last_insert_id()"));

		cmd.Execute();



		while( cmd.FetchNext() )

		{

			sa_printf(_TSA("%d"),  cmd[1].asLong());

			sa_printf(_TSA("\n"));

		}

	}

	catch(SAException &x)

	{

		sa_printf(_TSA("ERR: "));

		sa_printf((const SAChar*)x.ErrText());

		sa_printf(_TSA("\n"));

	}



	return 0;

}





/*

CREATE TABLE t1 (

id NUMBER(10),

description VARCHAR2(50),

CONSTRAINT t1_pk PRIMARY KEY (id)

);

CREATE SEQUENCE t1_seq;

*/



int mainss(int argc, char* argv[])

{

	SAConnection con; // create connection object



	try

	{

		con.Connect(

			"ora111",  // database name

			"sys",				// user name

			"java",			// password

			SA_Oracle_Client);



		SACommand cmd(&con, _TSA("delete from t1"));

		cmd.Execute();



		cmd.setCommandText(_TSA("insert into t1(id,description) values(t1_seq.nextval, 'test') returning id into :idval"));

		SAParam& p = cmd.Param(_TSA("idval"));

		p.setParamDirType(SA_ParamOutput);

		// !important!

		p.setAsLong();

		p.setParamType(SA_dtLong);



		cmd.Execute();



		long nID = p.asLong();

		sa_printf(_TSA("NEW ID %d\n"),  nID);



		cmd.setCommandText(_TSA("select id,description from t1"));

		cmd.Execute();



		while( cmd.FetchNext() )

		{

			sa_printf(_TSA("%d "),  cmd[1].asLong());

			sa_printf((const SAChar*)cmd[2].asString());

			sa_printf(_TSA("\n"));

		}

	}

	catch(SAException &x)

	{

		sa_printf(_TSA("ERR: "));

		sa_printf((const SAChar*)x.ErrText());

		sa_printf(_TSA("\n"));

	}



	return 0;

}



int mainnnnn()

{

	try

	{

		SAConnection conn;

		conn.Connect( "172.16.1.89/ORCL.india.checktronix.com", "SYSTEM",

			"sa123", SA_Oracle_Client );



		SACommand cmd;

		cmd.setConnection( &conn );



		const char *str = "683333_cv_Resumé.doc";

		size_t len = 20;

		int key = 142891751;



		cmd.setCommandText("INSERT INTO TBLDOCDETAILS(FDOCKEY, FDOCID) VALUES(:1, :2)");

		cmd.Param(1).setAsLong() = key;

		cmd.Param(2).setAsBLob() = SAString( str, (int)len );

		cmd.Execute();



		cmd.setCommandText("SELECT * FROM TBLDOCDETAILS;");

		cmd.Execute();



		if( cmd.isResultSet() )

		{

			while( cmd.FetchNext() )

			{

				long fdockey = cmd.Field("FDOCKEY").asLong();

				std::cout << "\n" << fdockey;

			}

		}

		conn.Disconnect();

		std::cout << "Operation sucess";

	}

	catch ( SAException &ex )

	{

		std::cout << (const SAChar*)ex.ErrText();

		return -1;

	}



	return 0;

}


/*
USE [test]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[t1](
	[f1] [int] IDENTITY(1,1) NOT NULL,
	[f2] [nvarchar](50) NULL
) ON [PRIMARY]

GO
*/
int main(int argc, char** argv)
{
	SAConnection con;

	try
	{
		con.setOption(_TSA("SQLNCLI.LIBS")) = _TSA("msodbcsql11.dll");
		con.Connect(
			_TSA("BEDLAM-M\\EN2014@test"), _TSA(""), _TSA(""), SA_SQLServer_Client);
		con.setAutoCommit(SA_AutoCommitOff);
		SACommand cmd(&con, _TSA("insert into t1(f2) values('test')"));
		cmd.Execute();
		con.Commit();
		cmd.setCommandText(_TSA("select f1,f2 from t1"));
		cmd.Execute();
		while( cmd.FetchNext() ) {
			sa_printf((const SAChar*)cmd[1].asString());
			sa_printf(_TSA(" "));
			sa_printf((const SAChar*)cmd[2].asString());
			sa_printf(_TSA("\n"));
		}
	}
	catch( SAException &x )
	{
		sa_printf(_TSA("ERR: "));
		sa_printf((const SAChar*)x.ErrText());
		sa_printf(_TSA("\n"));
	}
	return 0;
}

int mainnnnn(int argc, char** argv)
{
	//char* x = setlocale(LC_ALL, "");
	SAConnection con;

	try
	{
		//con.setOption(_TSA("ClientEncoding")) = _TSA("latin1");
		//con.Connect(_TSA("DSN=ol_informix1170;CLIENT_LOCALE=ru_RU.1251"), _TSA("informix"), _TSA("java"),
		//con.Connect(_TSA("Server=ol_informix1170;Database=test;DB_LOCALE=en_US.57372;NEEDODBCTYPESONLY=1"), _TSA("informix"), _TSA("java"),
		//con.Connect(_TSA("Server=ol_informix1170;Database=test"), _TSA("informix"), _TSA("java"),
		//	SA_Informix_Client);
		//con.Connect(_TSA("bedlam-m@test;AutoTranslate=yes"), _TSA("sa"), _TSA("java"),
		//		SA_SQLServer_Client);
		//con.setOption(_TSA("ODBCUseNumeric")) = _TSA("TRUE");
		//con.Connect(_TSA("EN2012"), _TSA("sa"), _TSA("java1970"),
		//		SA_ODBC_Client);
		con.setOption(_TSA("DB2CLI.LIBS")) = _TSA("D:\\download\\DB2\\clidriver\\bin\\db2cli64.dll");
		//con.Connect(_TSA("Hostname=bedlam-home.bedlam;Database=test;ServiceName=50000;Protocol=TCPIP"), _TSA("db2inst1"), _TSA("java"), SA_DB2_Client);
		con.setClient(SA_SQLAnywhere_Client);

		long nVersionClient = con.ClientVersion();
		if(nVersionClient)
		{
			short minor = (short)(nVersionClient & 0xFFFF);
			short major = (short)(nVersionClient >> 16);

			sa_printf(_TSA("Client version: %hd.%hd\n"), major, minor);
		}
		else
		{
			sa_printf(_TSA("Client version: unknown before connection\n"));
		}
		con.Connect(_TSA("Server=demo12"), _TSA("DBA"), _TSA("sql"), SA_SQLAnywhere_Client);

		/*
		long nVersionServer = con.ServerVersion();
		short minor = (short)(nVersionServer & 0xFFFF);
		short major = (short)(nVersionServer >> 16);
		sa_printf(_TSA("Server: %s\n"), (const SAChar*)con.ServerVersionString());
		sa_printf(_TSA("Server version: %hd.%hd\n"), major, minor);
		if(!nVersionClient)
		{
		nVersionClient = con.ClientVersion();
		if(nVersionClient)
		{
		short minor = (short)(nVersionClient & 0xFFFF);
		short major = (short)(nVersionClient >> 16);
		sa_printf(_TSA("Client version: %hd.%hd\n"), major, minor);
		}
		else
		{
		sa_printf(_TSA("Client version: unknown after connection\n"));
		}
		}
		*/

		SACommand cmd(&con, _TSA("p1"));
		cmd.Param(_TSA("pId")).setAsLong() = 1;
		//cmd.Param("cOut").setAsString() = _TSA("xxx");
		cmd.Execute();
		SAString p1 = cmd.Param("cOut").asString();
		long result = cmd.Param("return_value");

		/*
		cmd.setCommandText(_TSA("drop table if exists t1"));
		cmd.Execute();

		cmd.setCommandText(_TSA("create table t1(f1 BINARY(100))"));
		cmd.Execute();

		cmd.setCommandText(_TSA("insert into t1(f1) values(:1)"));
		cmd.Param(1).setAsBytes() = SAString((const void*)"01234", 5);
		cmd.Execute();

		con.Commit();

		cmd.setCommandText(_TSA("select f1 from t1"));
		cmd.Execute();
		cmd.Field(1).setLongOrLobReaderMode(SA_LongOrLobReaderManual);
		*/
		while( cmd.isResultSet() ) {
			while( cmd.FetchNext() ) {
				SAString s = cmd[1].asString();
				sa_printf((const SAChar*)s);
				sa_printf(_TSA("\n"));
			}
		}

		/*
		cmd.Execute();
		while( cmd.isResultSet() ) {
		while( cmd.FetchNext() ) {
		SAString s = cmd[1].asString();
		sa_printf((const SAChar*)s);
		sa_printf(_TSA("\n"));
		}
		}
		*/
	}
	catch( SAException &x )
	{
		sa_printf(_TSA("ERR: "));
		sa_printf((const SAChar*)x.ErrText());
		sa_printf(_TSA("\n"));
	}
	return 0;
}



int mainX2(int argc, char** argv)

{

	SAConnection con;



	try

	{

		con.setOption(_TSA("DB2CLI.LIBS")) =

			_TSA("D:\\download\\DB2\\clidriver\\bin\\db2cli64.dll");

		con.Connect(_TSA("Hostname=bedlam-home.bedlam;Database=test;ServiceName=50000;Protocol=TCPIP"),

			_TSA("db2inst1"), _TSA("java"), SA_DB2_Client);



		SACommand cmd(&con);

		cmd.setCommandText(_TSA("select f2 from t1 where f1=1"));

		cmd.Execute();

		while( cmd.FetchNext() ) {

			sa_printf((const SAChar*)cmd[1].asString());

			sa_printf(_TSA("\n"));

		}

	}

	catch( SAException &x )

	{

		sa_printf(_TSA("ERR: "));

		sa_printf((const SAChar*)x.ErrText());

		sa_printf(_TSA("\n"));

	}



	return 0;

}



/*

// -L../SQLAPI/include -L../SQLAPI/include/sybase

#include <sybAPI.h>



void sybMsgCallback(void *pMessageStruct, bool bIsServerMessage, void *pAddInfo)

{

if( bIsServerMessage )

{

// native OCS server message

CS_SERVERMSG *message = (CS_SERVERMSG *)pMessageStruct;

//..

}

else

{

// native OCS client message

CS_CLIENTMSG *message = (CS_CLIENTMSG *)pMessageStruct;

//..

}

}



void test1()

{

SAConnection con;

con.Connect("...", "sa", "pwd", SA_Sybase_Client);

// per connection handler

sybAPI::SetMessageCallback(sybMsgCallback, NULL, &con);

//...

}

*/