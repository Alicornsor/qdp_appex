
void test_scroll(SAConnection &con)
{
	SACommand cmd(&con);
	cmd.setOption("UseCursor") = "1";
	cmd.setOption("UseDynamicCursor") = "1";

	cmd.setCommandText("select f1 from t1");
	cmd.Execute();

	int ch;
	printf("ENTER n,p,f,l or q to quit.\n");

	do {
		ch = _getch();
		bool bResult = false;

		try
		{
			switch(ch)
			{
			case 'n':
				bResult = cmd.FetchNext();
				break;
			case 'p':
				bResult = cmd.FetchPrior();
				break;
			case 'f':
				bResult = cmd.FetchFirst();
				break;
			case 'l':
				bResult = cmd.FetchLast();
				break;
			}
		}
		catch(SAException &x)
		{
			printf("ERROR: %s\n", (const char*)x.ErrText());
		}

		if( bResult )
			printf("RESULT: %s.\n", (const char*)cmd[1].asString());
		else if( ch != 'q' )
			printf("NO DATA.\n");

	} while ( ch != 'q' );
}

int main(int argc, char **argv)
{
	SAConnection con;

	try
	{
		//con.setOption("UseAPI") = "OCI7";
		//con.Connect( "ora102", "sys", "java", SA_Oracle_Client);
		//con.setOption("UseAPI") = "DB-Library";
		//con.setOption("SSPROP_INIT_MARSCONNECTION") = "VARIANT_FALSE";
		con.Connect( "BEDLAM@pubs", "sa", "java", SA_SQLServer_Client);
		//con.Connect( "LocalServer", "sa", "java", SA_ODBC_Client);
		//con.Connect( "test", "postgres", "java", SA_PostgreSQL_Client);
	
	}
	catch( SAException& x )
	{
		printf("ERROR: %s\n", (const char*) x.ErrText());
		exit(1);
	}

	test_scroll(con);

	return 0;
}
