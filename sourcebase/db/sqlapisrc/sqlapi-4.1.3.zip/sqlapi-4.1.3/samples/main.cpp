#include <iostream>

#include <SQLAPI.h>


int main(int argc, const char* argv[] ){
    try
    {
        SAConnection con;

        // Windows
        // con.Connect("Driver=SQLite3 ODBC Driver;Database=/tmp/test.db", "", "", SA_ODBC_Client);
        
        // Linux:
        con.Connect("Driver=SQLITE33;Database=/tmp/test.db", "", "", SA_ODBC_Client);
        
        con.Disconnect();
    }
    catch(SAException &x){
        std::cerr << "SAException: " << x.ErrText().GetMultiByteChars() << std::endl; 
        return -1;
    }
    catch( std::exception& e){
        std::cerr <<  "exception: " << e.what() << std::endl;
        return -2;
    }
    catch( ... ){
        std::cerr << "unknown exception occured" << std::endl;
        return -3;
    }
    return 0;
}
